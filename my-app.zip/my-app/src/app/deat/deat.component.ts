import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deat',
  templateUrl: './deat.component.html',
  styleUrls: ['./deat.component.css']
})
export class DeatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
